var namespaces =
[
    [ "ggicci", "namespaceggicci.html", null ]
];