var structggicci_1_1_json_1_1_illegal_operation_exception =
[
    [ "OperationKind", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a22558a4529bac39417b96630d07eabe4", [
      [ "kExtract", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a22558a4529bac39417b96630d07eabe4a626b195ff11b6e5df5ad092b66c6d1ad", null ],
      [ "kViolateAccess", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a22558a4529bac39417b96630d07eabe4a7c917abb002a0849d487cd8df662a514", null ],
      [ "kPush", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a22558a4529bac39417b96630d07eabe4a6f429821e3eb53dacedd3df75139f68e", null ],
      [ "kAddProperty", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a22558a4529bac39417b96630d07eabe4aada3d891ba95737d36c59baeceeffccc", null ],
      [ "kRemove", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a22558a4529bac39417b96630d07eabe4aa31088225860fdcf14fd8ec3d8c0e05b", null ],
      [ "kRetriveKeys", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a22558a4529bac39417b96630d07eabe4aada583a6b7c07024bdbeee27a2501815", null ]
    ] ],
    [ "IllegalOperationException", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a2a69f1241c69eb20a3bee5e2d64963a2", null ],
    [ "what", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a9e998602be41f9805fe80d3b26e99922", null ],
    [ "from_", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a4e34012075abdedc37f1a2cd9326f8f7", null ],
    [ "kind_", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a11950c7842720725b9949663e1cfa4fa", null ],
    [ "to_", "structggicci_1_1_json_1_1_illegal_operation_exception.html#a0f192707b586549acafe937c442c1845", null ]
];