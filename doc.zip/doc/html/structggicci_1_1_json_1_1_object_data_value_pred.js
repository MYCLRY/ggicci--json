var structggicci_1_1_json_1_1_object_data_value_pred =
[
    [ "ObjectDataValuePred", "structggicci_1_1_json_1_1_object_data_value_pred.html#a965d79fd370ccc7691acaddb8e65a765", null ],
    [ "operator()", "structggicci_1_1_json_1_1_object_data_value_pred.html#a9d8befc79c59ef58c11ab25e91c1f144", null ],
    [ "json_", "structggicci_1_1_json_1_1_object_data_value_pred.html#ac6f50c58b9cd30e092e56736528377f2", null ]
];