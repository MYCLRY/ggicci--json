var structggicci_1_1_json_1_1_unexpected_token_exception =
[
    [ "UnexpectedTokenException", "structggicci_1_1_json_1_1_unexpected_token_exception.html#af21c96536ff6892f689273cf17495541", null ],
    [ "what", "structggicci_1_1_json_1_1_unexpected_token_exception.html#ae32892a2fb3eb8cec92c2575f314ca78", null ],
    [ "ch_", "structggicci_1_1_json_1_1_unexpected_token_exception.html#a288522bb3b055c631935fc386833eb35", null ],
    [ "pos_", "structggicci_1_1_json_1_1_unexpected_token_exception.html#a4598755d7bdb517964b9edd14b469e84", null ]
];