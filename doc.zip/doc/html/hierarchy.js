var hierarchy =
[
    [ "exception", null, [
      [ "ggicci::Json::BadConversionException", "structggicci_1_1_json_1_1_bad_conversion_exception.html", null ],
      [ "ggicci::Json::UnexpectedTokenException", "structggicci_1_1_json_1_1_unexpected_token_exception.html", null ]
    ] ],
    [ "ggicci::Json", "classggicci_1_1_json.html", null ],
    [ "ggicci::Json::Parser", "structggicci_1_1_json_1_1_parser.html", null ]
];