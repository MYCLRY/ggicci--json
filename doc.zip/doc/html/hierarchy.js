var hierarchy =
[
    [ "ggicci::Json::Assist", "structggicci_1_1_json_1_1_assist.html", null ],
    [ "exception", null, [
      [ "ggicci::Json::IllegalOperationException", "structggicci_1_1_json_1_1_illegal_operation_exception.html", null ],
      [ "ggicci::Json::UnexpectedTokenException", "structggicci_1_1_json_1_1_unexpected_token_exception.html", null ]
    ] ],
    [ "ggicci::Json", "classggicci_1_1_json.html", null ],
    [ "ggicci::Json::ObjectDataValuePred", "structggicci_1_1_json_1_1_object_data_value_pred.html", null ]
];